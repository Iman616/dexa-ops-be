<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Purchase Order - <?php echo e($po->po_number); ?></title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
      font-size: 9pt;
      line-height: 1.3;
      color: #000;
    }

    .container {
      padding: 15px 30px;
    }

    /* Header / Kop Surat */
    .header-section {
      text-align: center;
      margin-bottom: 20px;
      border-bottom: 2px solid #000;
      padding-bottom: 10px;
    }

    .header-section img {
      max-width: 100%;
      height: auto;
    }

    /* Title */
    .title-section {
      text-align: center;
      margin: 15px 0;
    }

    .title {
      font-size: 11pt;
      font-weight: bold;
      text-decoration: underline;
      letter-spacing: 1px;
    }

    /* Info Section - Two Columns */
    .info-section {
      margin-bottom: 20px;
    }

    .info-row {
      display: table;
      width: 100%;
      margin-bottom: 3px;
    }

    .info-left {
      display: table-cell;
      width: 50%;
      vertical-align: top;
      font-size: 9pt;
    }

    .info-right {
    display: table-cell;
    width: 50%;
    vertical-align: top;
    padding-left: 30px;
    font-size: 9pt;
    text-align: right;  
  }

    .info-label {
      display: inline-block;
      width: 110px;
      font-weight: normal;
    }

    /* Opening Text */
    .opening-text {
      margin: 12px 0;
      text-align: justify;
      line-height: 1.5;
      font-size: 9pt;
    }

    /* Items Table */
    .items-table {
      width: 100%;
      border-collapse: collapse;
      margin: 15px 0;
      font-size: 9pt;
    }

    .items-table th {
      border: 1px solid #000;
      padding: 5px 6px;
      text-align: center;
      font-weight: bold;
      background-color: #fff;
      font-size: 9pt;
    }

    .items-table td {
      border: 1px solid #000;
      padding: 5px 6px;
      vertical-align: top;
      font-size: 9pt;
    }

    .text-center {
      text-align: center;
    }

    .text-right {
      text-align: right;
    }

    .text-left {
      text-align: left;
    }

    /* Summary Rows */
    .items-table .summary-row td {
      border: 1px solid #000;
      font-weight: normal;
    }

    .items-table .total-row td {
      border: 1px solid #000;
      font-weight: bold;
    }

    /* Closing Text */
    .closing-text {
      margin: 15px 0;
      text-align: justify;
      line-height: 1.5;
      font-size: 9pt;
    }

    /* Signature */
    .signature-section {
      margin-top: 25px;
    }

    .signature-title {
      font-size: 9pt;
      margin-bottom: 5px;
    }

    .signature-image {
      margin: 10px 0;
      max-width: 150px;
      height: auto;
    }

    .signature-name {
      text-decoration: underline;
      font-weight: bold;
      font-size: 9pt;
      margin-top: 60px;
    }

    .signature-position {
      font-size: 9pt;
      margin-top: 3px;
    }
  </style>
</head>

<body>
  <div class="container">
    <!-- Header / Kop Surat dengan Border -->
    <div class="header-section">
      <?php if($company->logo_path): ?>
        <img src="<?php echo e(public_path('storage/' . $company->logo_path)); ?>" alt="Logo Company">
      <?php endif; ?>
    </div>

    <!-- Title -->
    <div class="title-section">
      <div class="title">PURCHASE ORDER</div>
    </div>

    <!-- Customer and PO Info - Two Columns Layout -->
  <!-- Customer and PO Info - Two Columns Layout -->
<div class="info-section">
  <!-- Row 1 -->
  <div class="info-row">
    <div class="info-left">
      <span class="info-label">To</span>: <strong><?php echo e($customer->customer_name); ?></strong>
    </div>
    <div class="info-right">
      Date Purchase&nbsp;&nbsp;&nbsp;: <?php echo e(\App\Services\PurchaseOrderPdfService::formatDate($po->po_date)); ?>

    </div>
  </div>

  <!-- Row 2 -->
  <div class="info-row">
    <div class="info-left">
      <span class="info-label"></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($customer->address ?? ''); ?>

    </div>
    <div class="info-right">
      Number Purchase : <?php echo e($po->po_number); ?>

    </div>
  </div>

  <!-- Row 3 -->
  <div class="info-row">
    <div class="info-left">
      <span class="info-label"></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($customer->city ?? ''); ?><?php echo e($customer->province ? ', ' . $customer->province : ''); ?>

    </div>
    <div class="info-right">
      &nbsp;
    </div>
  </div>

  <!-- Row 4 -->
  <div class="info-row">
    <div class="info-left">
      <span class="info-label">Up</span>: <?php echo e($customer->contact_person ?? '-'); ?>

    </div>
    <div class="info-right">
      Contact person&nbsp;&nbsp;: <?php echo e($customer->contact_person ?? '-'); ?>

    </div>
  </div>

  <!-- Row 5 -->
  <div class="info-row">
    <div class="info-left">
      <span class="info-label">Tlp/Fax</span>: <?php echo e($customer->phone ?? '-'); ?>

    </div>
    <div class="info-right">
      Phone&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <?php echo e($customer->phone ?? '-'); ?>

    </div>
  </div>
  
  <!-- Row 6 - Phone line 2 jika ada -->
  <?php if($customer->phone2): ?>
  <div class="info-row">
    <div class="info-left">
      &nbsp;
    </div>
    <div class="info-right">
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e($customer->phone2); ?>

    </div>
  </div>
  <?php endif; ?>
</div>

    <!-- Opening Text -->
    <div class="opening-text">
      Dengan hormat,
    </div>

    <div class="opening-text">
      Menindaklanjuti penawaran yang sudah diberikan, maka dengan ini kami bermaksud untuk melakukan pemesanan dengan spesifikasi sebagai berikut :
    </div>

    <!-- Items Table -->
  <!-- Items Table -->
<table class="items-table">
  <thead>
    <tr>
      <th style="width: 4%;" rowspan="2">No</th>
      <th style="width: 26%;" rowspan="2">Nama Barang</th>
      <th style="width: 16%;" rowspan="2">Katalog</th>
      <th style="width: 10%;" colspan="2">Jumlah</th>
      <th style="width: 16%;" rowspan="2">Harga Satuan</th>
      <th style="width: 10%;" rowspan="2">Diskon</th>
      <th style="width: 18%;" rowspan="2">Total Harga</th>
    </tr>
    <tr>
      <th style="width: 6%; border-left: 1px solid #000;">Qty</th>
      <th style="width: 4%; border-left: 1px solid #000;">Unit</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td class="text-center"><?php echo e($index + 1); ?></td>
        <td class="text-left"><?php echo e($item->product_name); ?></td>
        <td class="text-left"><?php echo e($item->specification ?? '-'); ?></td>
        <td class="text-center" style="border-right: none;"><?php echo e(number_format($item->quantity, 0, ',', '.')); ?></td>
        <td class="text-center" style="border-left: 1px solid #000;"><?php echo e($item->unit); ?></td>
        <td class="text-right">Rp&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(number_format($item->unit_price, 0, ',', '.')); ?></td>
        <td class="text-center"><?php echo e(number_format($item->discount_percent, 1, ',', '.')); ?>%</td>
        <td class="text-right">Rp&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(number_format($item->total, 0, ',', '.')); ?></td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Summary Rows -->
    <tr class="summary-row">
      <td colspan="7" class="text-right"><strong>Subtotal</strong></td>
      <td class="text-right"><strong>Rp&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(number_format($subtotal, 0, ',', '.')); ?></strong></td>
    </tr>
    <tr class="summary-row">
      <td colspan="7" class="text-right"><strong>PPN</strong></td>
      <td class="text-right"><strong>Rp&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(number_format($ppn, 0, ',', '.')); ?></strong></td>
    </tr>
    <tr class="total-row">
      <td colspan="7" class="text-right"><strong>Total</strong></td>
      <td class="text-right"><strong>Rp&nbsp;&nbsp;&nbsp;&nbsp;<?php echo e(number_format($grand_total, 0, ',', '.')); ?></strong></td>
    </tr>
  </tbody>
</table>


    <!-- Closing Text -->
    <div class="closing-text">
      Demikian Purchase Order ini dibuat untuk ditindaklanjuti. Atas perhatian dan kerjasamanya, kami ucapkan terima kasih.
    </div>

    <!-- Signature Section -->
    <div class="signature-section">
      <div class="signature-title">Best Regards</div>
      
      <?php if($po->signature_image): ?>
        <div style="margin-top: 10px;">
          <img 
            src="<?php echo e(public_path('storage/' . $po->signature_image)); ?>" 
            class="signature-image"
            alt="Signature"
          >
        </div>
      <?php endif; ?>

      <div class="signature-name" style="margin-top: <?php echo e($po->signature_image ? '10px' : '60px'); ?>;">
        <?php echo e($po->signed_name ?? '_______________________'); ?>

      </div>
      
      <?php if($po->signed_position): ?>
        <div class="signature-position">
          <?php echo e($po->signed_position); ?>

        </div>
      <?php endif; ?>
    </div>

  </div>
</body>

</html><?php /**PATH D:\laragon\www\dexa-ops-be\backend-api\resources\views/pdf/purchase_order.blade.php ENDPATH**/ ?>